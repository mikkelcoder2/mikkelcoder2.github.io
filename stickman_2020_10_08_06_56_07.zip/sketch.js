function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(400);
function draw(){
}ellipse (200,100,100)
  
line(200,150,200,300)
 line(200,200,100,150)
 line(200,50,100,150)
 line (200,200,300,200)
 line(200,300,370,550)
 line(125,390,200,300)
 ellipse(180,90,25)
 ellipse(220,90,25)
 arc(200,140,60,25,60,50)
}